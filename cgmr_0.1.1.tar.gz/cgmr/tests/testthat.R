library(testthat)
library(cgmr)

test_check("cgmr")
