#' Activity file
#'
#' @format a dataframe of 5 variables
"activity_raw"

#' Glucose data
#'
#' @format a dataframe of 6 variables: time, scan, hist, strip, food, value
"glucose_raw"
